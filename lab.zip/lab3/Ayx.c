#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

sem_t *K;
sem_t *djedbozicnjak;
sem_t *sobovi;
sem_t *konzultacije;

int *br_sobova;
int *br_patuljaka;

int djed_bozicnjak_pid;
int sjeverni_pol_pid;

void sob(int id) {
    sem_wait(K);
    *br_sobova = *br_sobova + 1;
    printf("Dolazi sob %d, sada je ukupno %d sobova.\n", id, *br_sobova);
    if (*br_sobova == 10) {
        printf("Skupilo se 10 sobova.\n");
        int djedbozicnjak_spava;
        sem_getvalue(djedbozicnjak, &djedbozicnjak_spava);
        if (djedbozicnjak_spava == 0) sem_post(djedbozicnjak);
    }
    sem_post(K);
    sem_wait(sobovi);
    printf("Sob %d je poslan na godisnji odmor.\n", id);
}

void patuljak(int id) {
    sem_wait(K);
    *br_patuljaka = *br_patuljaka + 1;
    printf("Dolazi patuljak %d, sada je ukupno %d patuljaka.\n", id, *br_patuljaka);
    if (*br_patuljaka == 3) {
        printf("Patuljak %d budi Djeda Bozicnjaka.\n", id);
        int djedbozicnjak_spava;
        sem_getvalue(djedbozicnjak, &djedbozicnjak_spava);
        if (djedbozicnjak_spava == 0) sem_post(djedbozicnjak);
    }
    sem_post(K);
    sem_wait(konzultacije);
    printf("Patuljku %d je rijesen problem.\n", id);
}

void djed_bozicnjak() {
    while(1) {
        printf("Djed Bozicnjak spava.\n");

        sem_wait(djedbozicnjak);
        sem_wait(K);

        if (*br_sobova == 10 && *br_patuljaka > 0) {
            sem_post(K);
            printf("Djed Bozicnjak ukrcava poklone i raznosi.\n");
            sleep(2);
            printf("Djed Bozicnjak je gotov s raznosenjem poklona.\n");
            sem_wait(K);

            for (int i = 0; i < 10; i++) sem_post(sobovi);
            *br_sobova = 0;
        }
        if (*br_sobova == 10) {
            sem_post(K);
            printf("Djed Bozicnjak hrani sobove.\n");
            sleep(2);
            printf("Djed Bozicnjak je nahranio sobove.\n");
            sem_wait(K);
        }
        while (*br_patuljaka >= 3) {
            sem_post(K);
            printf("Djed Bozicnjak rjesava problem patuljaka.\n");
            sleep(2);
            printf("Djed Bozicnjak je rijesio problem patuljaka.\n");
            sem_wait(K);

            for (int i = 0; i < 3; i++) sem_post(konzultacije);
            *br_patuljaka = *br_patuljaka - 3;
        }

        sem_post(K);
    }
}

void sjeverni_pol() {
    int id = 0;
    while(1) {
        sleep(rand() % (3 - 1 + 1) + 1);
        if ((double)rand() / (double)RAND_MAX > 0.5 && *br_sobova < 10) {
            id++;
            if (fork() == 0) {
                sob(id);
                exit(0);
            }
        }
        if ((double)rand() / (double)RAND_MAX > 0.5) {
            id++;
            if (fork() == 0) {
                patuljak(id);
                exit(0);
            }
        }
    }
}

void zaustavi() {
    sem_destroy(K);
    sem_destroy(djedbozicnjak);
    shmdt(K);
    shmdt(djedbozicnjak);
    shmdt(br_sobova);
    shmdt(br_patuljaka);
    kill(djed_bozicnjak_pid, SIGINT);
    kill(sjeverni_pol_pid, SIGINT);
    exit(0);
}

int main() {
    // inicijalizacija
    int ID_K = shmget(IPC_PRIVATE, sizeof(sem_t), 0600);
    if (ID_K == -1) exit(1);
    K = shmat(ID_K, NULL, 0);
    shmctl(ID_K, IPC_RMID, NULL);
    sem_init(K, 1, 1);

    int ID_djedbozicnjak = shmget(IPC_PRIVATE, sizeof(sem_t), 0600);
    if (ID_djedbozicnjak == -1) exit(1);
    djedbozicnjak = shmat(ID_djedbozicnjak, NULL, 0);
    shmctl(ID_djedbozicnjak, IPC_RMID, NULL);
    sem_init(djedbozicnjak, 1, 0);

    int ID_sobovi = shmget(IPC_PRIVATE, sizeof(sem_t), 0600);
    if (ID_sobovi == -1) exit(1);
    sobovi = shmat(ID_sobovi, NULL, 0);
    shmctl(ID_sobovi, IPC_RMID, NULL);
    sem_init(sobovi, 1, 0);

    int ID_konzultacije = shmget(IPC_PRIVATE, sizeof(sem_t), 0600);
    if (ID_konzultacije == -1) exit(1);
    konzultacije = shmat(ID_konzultacije, NULL, 0);
    shmctl(ID_konzultacije, IPC_RMID, NULL);
    sem_init(konzultacije, 1, 0);

    int ID_br_sobovi = shmget(IPC_PRIVATE, sizeof(int), 0600);
    if (ID_br_sobovi == -1) exit(1);
    br_sobova = shmat(ID_br_sobovi, NULL, 0);
    shmctl(ID_br_sobovi, IPC_RMID, NULL);
    *br_sobova = 0;

    int ID_patuljci = shmget(IPC_PRIVATE, sizeof(int), 0600);
    if (ID_patuljci == -1) exit(1);
    br_patuljaka = shmat(ID_patuljci, NULL, 0);
    shmctl(ID_patuljci, IPC_RMID, NULL);
    *br_patuljaka = 0;

    srand(time(0));
    sigset(SIGINT, zaustavi);

    // pokretanje procesa
    djed_bozicnjak_pid = fork();
    if (djed_bozicnjak_pid==0) {
        djed_bozicnjak();
        exit(0);
    }
    sjeverni_pol_pid = fork();
    if (sjeverni_pol_pid==0) {
        sjeverni_pol();
        exit(0);
    }

    while(1);
}