#include <stdio.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdatomic.h>
#include <stdbool.h>

#define broj_procesa 2

int SegID;
pid_t pid;

sem_t *sem_djedBozicnjak;  //bsem
sem_t *sem_konzultacije; //osem
sem_t *sem_sobovi; //osem
sem_t *sem_K; //Bsem GATE

atomic_int *br_sobova ;// broj sobova pred vratima
atomic_int *br_patuljaka ;// broj patuljaka pred vratima

void Patuljak_proces(void);

bool getValFromSem(sem_t *sem){
    int t;
    sem_getvalue(sem,&t);
    if(t==0) return true;
    return false;

}

void Djed_proces(void){

    while(1){

        printf("Djed spava\n");

        sem_wait(sem_djedBozicnjak);    //ČekajBSem(djedbozicnjak)
        sem_wait(sem_K);                //ČekajBSem(K)

        printf("Djed se probudio\n");

        if(*br_sobova==10 && *br_patuljaka >0){    //ako je (br_sobova == 10 i br_patuljaka > 0) {
            if(getValFromSem(sem_K)) {
                sem_post(sem_K);                        // PostaviBSem(K)
            }
            printf("Ukrcaj poklone i raznosi 2s \n");
            sleep(2);                               //sleep
            sem_wait(sem_K);                               //ČekajBSem(K)

            for (int i = 0; i < 10; ++i) {  // PostaviOSem(sobovi, 10) povećaj semafor za 10
                sem_post(sem_sobovi);
            }
            *br_sobova = 0;                  //br_sobova = 0
        }

        if(*br_sobova==10) {                 // ako je (svi_sobovi_pred_vratima) {
           if(getValFromSem(sem_K)) {
               sem_post(sem_K);                // PostaviBSem(K)
            }
            printf("Nahrani sobove 2s\n");  //nahrani_sobove //sleep(2)
            sleep(2);
            sem_wait(sem_K);                //ČekajBSem(K)
        }

        while(*br_patuljaka >=3){               //dok je (br_patuljaka >= 3) {

           if(getValFromSem(sem_K)) {
               sem_post(sem_K);                    //PostaviBSem(K)
           }
            printf("Rijesi problem od patuljaka 2s\n"); //riješi_njihov_problem
            sleep(2);  //sleep(2)

            sem_wait(sem_K);                    //ČekajBSem(K)

            for (int i = 0; i <3 ; ++i) {       //PostaviOSem(konzultacije, 3) povećaj semafor za 3
                sem_post(sem_konzultacije);
                *br_patuljaka=*(br_patuljaka)-1;  // br_patuljaka-=3;
            }
        }
       if(getValFromSem(sem_K)) {                         // PostaviBSem(K)
           sem_post(sem_K);
       }
    }

}

void Sob_proces(void){

    sem_wait(sem_K);                    //ČekajBSem(K)

    *br_sobova=*br_sobova+1;
    printf("Broj sobova %d koji cekaju djeda \n",*br_sobova); //    odi do djeda i pričekaj ga;

    if(*(br_sobova)==10){   //    ako(treba raznositi poklone) {

        printf("10 sobova je stiglo\n");

        if(getValFromSem(sem_djedBozicnjak)) {
            sem_post(sem_djedBozicnjak);
        }

    }
   if(getValFromSem(sem_K)) {
       sem_post(sem_K);
   }

    sem_wait(sem_sobovi);

    printf("Sobovi odlaze na godisnji\n");

}

void Sjerverni_pol_proces(void) {

    while (1) {
        double x = ((double) rand() / RAND_MAX) * (3 - 1) + 1; // čekaj_slučajno_vrijeme //od 1 do 3 sekunde
        sleep(x);
        if ((((double) rand() / RAND_MAX) * (100 - 0) + 0) > 50
                && *br_sobova<10                        ) { //ako je (vjerojatnost_pojavljivanja_soba_velika(>50%) i
                                                                                //nisu_se_svi_sobovi_već_vratili) {

            pid = fork();

            if ( pid == 0 ) {

                // TODO stvori_dretvu_soba()
                Sob_proces();

                exit(0);

            }else if (pid == -1) {
                perror("Greska pri stvaranju procesa Sob");
                exit(1);
            }

        }

        if ((((double) rand() / RAND_MAX) * (100 - 0) + 0) > 50) { //ako je (vjerojatnost_pojavljivanja_patuljka_velika(>50%)){

            pid = fork();

            if ( pid == 0 ) {

                Patuljak_proces();
                exit(0);

            }else if (pid == -1) {
                perror("Greska pri stvaranju procesa Patuljak");
                exit(1);
            }
        }
    }
}

void Patuljak_proces(void){

    sem_wait(sem_K);//ČekajBSem(K)

    *(br_patuljaka)=*(br_patuljaka)+1;   //br_patuljaka++

    printf("Broj patuljaka koji cekaju djedovu pomoc %d\n",*br_patuljaka);

    if(*br_patuljaka==3){             //ako je (br_patuljaka == 3) {//ovaj je treći

        printf("3 patuljaka je na konzultacijama kod Djeda\n");

        if(getValFromSem(sem_djedBozicnjak)) {
            sem_post(sem_djedBozicnjak);    //PostaviBSem(djedbozicnjak)
        }
    }
    if(getValFromSem(sem_K)) {
       sem_post(sem_K);                    //PostaviBSem(K)
    }

    sem_wait(sem_konzultacije);         //ČekajOSem(konzultacije)

    printf("Patuljak gotov \n");
}

int main ()
{
    //TODO: stavi novu velicinu memorije
    SegID = shmget(IPC_PRIVATE, sizeof(sem_t)*4+sizeof(atomic_int)*2, 0600); //zauzimanje zajednicke memorije

    if (SegID == -1) {
        fprintf(stderr, "Nema memorije!\n");
        exit(1);
    }

    sem_djedBozicnjak = (sem_t *) shmat(SegID, NULL, 0);
    sem_konzultacije = (sem_t *) ( sem_djedBozicnjak+1);
    sem_sobovi = (sem_t *)  (sem_konzultacije+1);
    sem_K=(sem_t *) (sem_sobovi+1);

    br_sobova = (atomic_int *) (sem_K + 1);
    br_patuljaka=br_sobova+1;

    //TODO popravi vrijednosti OSEM
    sem_init(sem_djedBozicnjak, 1, 0); // djed je BSEM
    sem_init(sem_K, 1, 1);            // K  je BSEM
    sem_init(sem_konzultacije, 1, 0); // konzultacije  su OSEM
    sem_init(sem_sobovi, 1, 0); // sobovi je OSEM

    //TODO postavi br_sobova i brPatuljaka
    *br_sobova=0;
    *br_patuljaka=0;

    pid = fork();
    
    if ( pid == 0 ) {
        
        Djed_proces() ;
        exit(0);
    }
    else if (pid == -1) {
        perror("Greska pri stvaranju procesa Djed");
        exit(1);
    }

    pid = fork();

    if ( pid == 0 ) {

        Sjerverni_pol_proces() ;

        exit(0);
    }else if (pid == -1) {
        perror("Greska pri stvaranju procesa Sjeverni pol");
        exit(1);
    }

    for (int i = 0; i < broj_procesa; i++ ) //broj procesa=2
        wait(NULL);

    sem_destroy(sem_djedBozicnjak);
    sem_destroy(sem_konzultacije);
    sem_destroy(sem_sobovi);

    shmdt(sem_djedBozicnjak);
    shmdt(sem_konzultacije);
    shmdt(sem_sobovi);


    shmdt((char *) br_sobova);                  //      oslobadanje memorije
    shmdt((char *) br_patuljaka);

    shmctl(SegID,IPC_RMID,NULL);

    return 0;
}
