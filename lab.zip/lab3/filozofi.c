#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

pthread_mutex_t m;     //monitor
pthread_cond_t red[5]; //redovi uvjeta

int p[5]={4,3,2,1,0};

int *vilica[]={1,1,1,1,1};

char trenutno_stanje[]={'0',' ','0',' ','0',' ','0',' ','0',' ','\0'};

void parseOutput(int n,char x){

    trenutno_stanje[n*2]=x;
}

void ispisFilozofa(int x){
    printf("%s (%d)\n",trenutno_stanje,x+1);
}

void *filozof (void *p) {
    while (1) {                     //ponavljati
        int id = *((int *) p);

        sleep(3); //misliti

        pthread_mutex_lock(&m);               //udi u KO

            //TODO filozof[n]='o';      //X-jede, O-razmišlja, o-čeka na vilice)
            parseOutput(id,'o');

            while(vilica[id] == 0 || vilica[(id+1) % 5]==0){  //dok (vilica[n] == 0 || vilica[(n + 1) % 5] == 0)
                pthread_cond_wait(&red[id], &m);          //čekaj_u_redu_uvjeta(red[n]);
            }                                   //ako lijeva ili desna vilica nije dostupna blokiraj filozofa

            vilica[id]=0;            //vilica[n] = vilica[(n + 1) % 5] = 0;
            vilica[(id+1) % 5] = 0; // zauzmi vilicu do sebe
            //TODO filozof[n]='X';
            parseOutput(id,'X');  // jedi
            //TODO ispisi_stanje(id)
            ispisFilozofa(id);

        pthread_mutex_unlock(&m);               //izađi_iz_kritičnog_odsječka;

        sleep(2);                       //njam_njam;

        pthread_mutex_lock(&m);             //udi u KO

              //filozof[n] = 'O';
              parseOutput(id,'O');          //razmisljaj
              vilica[id] = 1;               //oslobodi vilice
              vilica[(id + 1) % 5]=1;  //vilica[n] = vilica[(n + 1) % 5] = 1;

              pthread_cond_signal(&red[(id-1) % 5]);            //oslobodi_dretvu_iz_reda(red[(n - 1) % 5]);
              pthread_cond_signal(&red[(id+1) % 5]);            //oslobodi_dretvu_iz_reda(red[(n + 1) % 5]);
              //TODO ispisi stanje
              ispisFilozofa(id);

        pthread_mutex_unlock(&m); //izađi_iz_kritičnog_odsječka;

    }

}
int main ()
{
	pthread_t t[5];
	int i;
    bool temp=false;

    for (int j = 0; j < 5; ++j) {
        if(!temp){
            temp=!temp;
            pthread_mutex_init (&m, NULL);
        }
        pthread_cond_init (&red[j], NULL);    
    }

    pthread_attr_t attr;

	for (i = 0; i < 5; i++) {
		pthread_create (&t[i], NULL, filozof, &p[4-i]);
		sleep(1);
	}
	for (i = 0; i < 5; i++)
		pthread_join (t[i], NULL);

	pthread_mutex_destroy (&m);
	
    for (int j = 0; j < 5; ++j) {
        pthread_cond_destroy (&red[j]);    
    }
	
	

	return 0;
}
