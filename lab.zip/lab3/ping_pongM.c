#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

char final[1024] = "";
int countDashes=0;

double randBetween(double m, double M)
{
    return ((double)rand()/RAND_MAX) * (M - m) + m;
}

int findFirstSmallestHole(int minSize,int end,int *ptr){

    int counterFreeSpaces=0;
    int index=-1;
    bool endSearch=false;


    for (int i = 0; i < countDashes ; ++i) {
        if(final[i]=='-'){
            int j=i;
            for (; final[j]=='-' ; ++j) {
                counterFreeSpaces++;
            }
            if( counterFreeSpaces>=minSize  ){
                index=i;
                *ptr=minSize+index;
                endSearch=true;

            }else{
                i+=counterFreeSpaces;
                counterFreeSpaces=0;
            }
        }
        if(endSearch)break;

    }
    return index;
}

void defragment(){

    char temp[1024]="";
    int emptySpaces=0;
    int k=0;

    for (int i = 0; i < countDashes; ++i) {
        if(final[i]=='-'){
                emptySpaces++;
        }else{
            temp[k]=final[i];
            k++;
        }
    }

    for (int i = k; i < k+emptySpaces ; ++i) {
        temp[i]='-';
    }

    for (int i = 0; i < countDashes; ++i) {
        final[i]=temp[i];
    }

    printf("%s\n",final);

}


int main (int argc, char *argv[])
{
    if(argc!=2){
        printf("Wrong argument number\n");
        exit(0);
    }
    int size=atoi(argv[1]);

    for (int j = 0; j < size; ++j) {
        final[j]='-';
        countDashes++;
    }

    //TODO ovo makni, sluzi za debug
//    char clean[]="";
//    strcpy(final,clean);
//    strcat(final,"-000--577-3333444-");
//    countDashes=strlen("-000--577-3333444-");

    printf("\n%s\n",final);

    int countRequest=0;
    int lastPosition=0;

    char z="";

    do{


        z=getchar();

        if(z=='z'){
            int randNumber=randBetween(1,5);
            //TODO debug purpose
           // randNumber=3;

            //TODO debug
            //countRequest=9;

            printf("Novi zahtjev %d (%c) za %d spremnicka mjesta\n",countRequest,countRequest+'0',randNumber);

            int i = lastPosition;
            randNumber+=i;
            int hole = findFirstSmallestHole(randNumber - i, randNumber, &randNumber);

            if(randNumber>=countDashes+1 || hole==-1){
                printf("Zahtjev se ne moze posluziti\n");
            }else {

                if (hole != -1) {
                    i = hole;
                }

                for (; i < randNumber; ++i) {

                    final[i] = countRequest + '0';

                }

                printf("%s\n", final);

                countRequest++;
                lastPosition = i;
            }

        }else if(z=='o'){
            printf("Koji zahtjev treba osloboditi?\n");
            char x;
            scanf(" %c",&x);
            printf("Oslobada se zahtjev %c\n",x);

            for (int i = 0; i <strlen(final) ; ++i) {
                if(final[i]==x){
                    final[i]='-';
                }
            }
            printf("%s\n",final);

        } else if(z=='d'){
            printf("Nakon defragmentacije\n");
            defragment();
        }


    }while (z!='k');


    printf("Kraj\n");


	return 0;
}
