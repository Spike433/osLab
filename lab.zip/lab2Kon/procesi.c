#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>


int SegID; /* identifikacijski broj segmenta */

//globalne varijable:

int *a;

int procesi=0,iteracije=0;

void proces() {

    for (int i = 0; i <iteracije ; ++i) {

        *a=*a+1;
    }

}


int main(int argc, char *argv[]) {

    procesi = atoi (argv[1]);
    iteracije = atoi (argv[2]);

    if (argc < 3) {
        fprintf (stderr,"Koristenje: %s broj_dretvi broj_iteracija", argv[0]);
        exit(1);
    }

    if(procesi<1 || iteracije<1  ){
        printf("Krivi unos");
        exit(2);
    }

    SegID = shmget(IPC_PRIVATE, sizeof(int), 0600); // 6 --> 110 u oktalnom

    if (SegID == -1) {
        fprintf(stderr, "Nema memorije!");
        exit(1);
    }

    a=(int *) shmat(SegID, NULL,    0);

    *a=0;

    for (int i = 0; i < procesi ; ++i) {
            if(fork()==0){
                proces(i);
                exit(0);
            }
    }

    int k=procesi;
    while( k--)  wait(NULL);


    printf("A=%d\n",*a);

    shmdt((char *) a);
    shmctl(SegID,IPC_RMID,NULL);


    return 0;
}