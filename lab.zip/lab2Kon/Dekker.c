#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <stdatomic.h>
#include <stdbool.h>


int SegID;

atomic_int *a;

atomic_int *PRAVO;
atomic_int *ZASTAVICA;

int procesi,iteracije;


void udi_u_kriticni_odsjecak(int i,int j) {   //  !funkcija! uđi_u_kritični_odsječak(i,j)

    ZASTAVICA[i]=1;                              //ZASTAVICA[i] = 1

    while(ZASTAVICA[j]!=0) {                       // dok je ZASTAVICA[j]<>0 čini {

        if(*PRAVO==j){                              //ako je PRAVO==j onda {

            ZASTAVICA[i]=0;                        //ZASTAVICA[i] = 0

            while(*PRAVO==j){                       //dok je PRAVO==j čini {
                //do nothing                       //ništa
            }
            ZASTAVICA[i]=1;                        //ZASTAVICA[i] = 1
        }
    }
}


void izadi_u_kriticni_odsjecak(int i,int j){    //funkcija izađi_iz_kritičnog_odsječka(i,j)
    *PRAVO=j;                                    //  PRAVO = j
    ZASTAVICA[i]=0;                             //  ZASTAVICA[i] = 0
}

void proces(int i) {                     //proces proc(i){ /* i [0,1] */

    int k;

    for (k = 0; k < iteracije; k++) {
        udi_u_kriticni_odsjecak(i,1-i );  //udi u kriticni odsjecak
        *a += 1;       //K.O
        izadi_u_kriticni_odsjecak(i,1-i); //izadi iz kricticnog odjecka
    }
}


int main(int argc, char *argv[])
{

    procesi = 2;
    iteracije = atoi (argv[2]);

    if(procesi<1 || iteracije<1  ){
        printf("Krivi unos");
        exit(1);
    }

    SegID = shmget(IPC_PRIVATE, sizeof(atomic_int)*4, 0600); //zauzimanje zajednicke memorije

    if (SegID == -1) {
        fprintf(stderr, "Nema memorije!\n");
        exit(1);
    }

    PRAVO = (atomic_int *) shmat(SegID, NULL,    0);
    ZASTAVICA = PRAVO + 1;
    a = PRAVO + 3;

    *a=0;
    *PRAVO = 0;
    ZASTAVICA[0] = ZASTAVICA[1] = 0;

    int i;
    for ( i = 0; i < procesi ; ++i) {     //pokretanje paralelnih procesa ,umjesto procesi staljvam 1
        if(fork()==0){
            proces(i);
            exit(0);
        }
    }


    while( i > 0){
        wait(NULL);  //cekanje djece
        i--;
    }


    printf("A=%d\n",*a);

    shmdt((char *) a);                  //      oslobadanje memorije
    shmctl(SegID,IPC_RMID,NULL);


    return 0;
}
