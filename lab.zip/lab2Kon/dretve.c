#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/wait.h>


//int SegID; /* identifikacijski broj segmenta */ --> ovo je slucajno oostalo i visak je

int dretve=0,iteracije=0;
int a;

void *dretvaFja (void *rbr);


int main(int argc, char *argv[]) {

    dretve = atoi (argv[1]);
    iteracije = atoi (argv[2]);

    a=0;

       int *iter;
    pthread_t *thre;

    if (argc < 3) {
        fprintf (stderr,
                 "Koristenje: %s broj_dretvi broj_iteracija\n", argv[0]);
        exit(1);
    }

    if(dretve<1 || iteracije<1  ){
        printf("Krivi unos");
        exit(1);
    }

     iter= malloc (dretve * sizeof(int));
    thre = malloc (dretve * sizeof(pthread_t));

    for (int i = 0; i <dretve ; ++i) {
        iter[i]=i;
        if ( pthread_create ( &thre[i], NULL, dretvaFja, &iter[i] ) ) {
            fprintf (stderr, "Ne mogu stvoriti novu dretvu!\n");
            exit(1);
        }

    }
    for (int i = 0; i < dretve; ++i) {
        pthread_join(thre[i],NULL); // ako ova naredba ne postoji , A=0
    }

    printf ("A=%d\n", a);


    return 0;
}

void *dretvaFja (void *rbr)
{
//    int *d = rbr;
    for (int i = 0; i < iteracije; ++i) {

        a=a+1;
    }


    return NULL;
}
