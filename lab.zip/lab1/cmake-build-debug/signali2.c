#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
void periodicki_posao(int sig){

    printf("Radim periodicki posao\n");
}

int main(){

    struct itimerval t;
    sigset(SIGALRM,periodicki_posao);

    t.it_value.tv_sec=0;
    t.it_value.tv_usec=500000;

    t.it_interval.tv_sec=0;
    t.it_interval.tv_usec=500000;
    setitimer(ITIMER_REAL,&t,NULL);

    while(1){
        pause();
    }
    return 0;

}