#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <stdlib.h>
#include <unistd.h>

int pid=0;
int sig[]={SIGQUIT,SIGALRM,SIGTERM,SIGUSR1};

void prekidna_rutina(int sig){

        kill(pid,SIGKILL);

    exit(0);
}
double rB(double mn, double mx)
{
    return ( (double)rand() /RAND_MAX) * ( mx - mn) + mn;
}

int main(int argc,char *argv[]){
    pid=atoi(argv[1]);
    sigset(SIGINT,prekidna_rutina);

    while(1){
        int random=rB(3,5);
      //  printf("Random 3-5 is: %ds\n",random);
        int randSig=rB(0,3);
        for (int i = 1; i <random ; ++i) {
            sleep(1);
        }
        kill(pid,sig[randSig]);

    }
    return 0;
}
