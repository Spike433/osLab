#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <math.h>
#include <stdbool.h>
#include <stdlib.h>

bool pauza=false;
unsigned    int  broj=  1000000001;
unsigned    int zadnji =1000000001;


bool prost ( unsigned long n );

 void   periodicki_ispis(){
        printf("zadnji prosti broj = %u\n",zadnji);
    }

bool    postavi_pauzu(){
        pauza=!pauza;
        return pauza;

    }

void    prekini(){
        printf("zadnji prosti broj = %u\n",zadnji);
        exit(0);
    }

int main(){
    sigset(SIGTERM, prekini);
    sigset(SIGINT,postavi_pauzu);

    struct itimerval t;
    sigset(SIGALRM,periodicki_ispis);

    t.it_value.tv_sec=5;
    t.it_value.tv_usec=0;

    t.it_interval.tv_sec=5;
    t.it_interval.tv_usec=0;

    setitimer(ITIMER_REAL,&t,NULL);


    while(1){

        if(prost(broj)){
            zadnji=broj;
        }
        broj++;
        while(pauza){
             pause();  //ako se makne nije problem, pause() je ljepse
        }
    }


    return 0;

}

bool prost ( unsigned long n ) {
    unsigned long i, max;
    if ( ( n & 1 ) == 0 ) /* je li paran? */
        return false;
    max = sqrt ( n );
    for ( i = 3; i <= max; i += 2 )
        if ( ( n % i ) == 0 )
            return false;
    return true; /* broj je prost! */
}