#include<stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>

#define N 6



int OZNAKA_CEKANJA[N];
int PRIORITET[N];
int TEKUCI_PRIORITET=0;
//int x;

int sig[]={SIGQUIT,SIGALRM,SIGTERM,SIGUSR1,SIGINT};

void zabrani_prekidanje(){

    int i;
    for(i=0; i<5; i++)
        sighold(sig[i]);

}

void dozvoli_prekidanje(){

    int i;
    for(i=0; i<5; i++)
        sigrelse(sig[i]);
}

int parsePrint(int x) {


        return x * 2;

}


void obrada_signala(int i){

                        //  1        2       3       4       5
    char temp[]={'-',' ', '-',' ' ,'-',' ', '-',' ','-',' ','-',' ', '\0'};

    temp[parsePrint(i)]='P';

    printf("%s\n",temp);

    for (int j = 1; j <= 5 ; ++j) {
        temp[parsePrint(i)] = j + '0';
        printf("%s\n", temp);
        sleep(1);
    }

    temp[parsePrint(i)]='K';
    printf("%s\n",temp);

    }



void prekidna_rutina(int sig){
    int n=-1;
    zabrani_prekidanje();
    switch (sig) {
        case SIGQUIT:
            n=1;
            printf("- X - - - -\n");
            break;
        case SIGALRM:
            n=2;
            printf("- - X - - -\n");
            break;
        case SIGTERM:
            n=3;
            printf("- - - X - -\n");
            break;

        case SIGUSR1:
            n=4;
            printf("- - - - X -\n");
            break;
        case SIGINT:
            n=5;
            printf("- - - - - X\n");
            break;


    }
    OZNAKA_CEKANJA[n]++; // sa ++ dozvoljeno je vise prekida iste razine

    int x;

   do{
         x=0;

        for (int j = TEKUCI_PRIORITET+1; j < N ; ++j) {
            if(OZNAKA_CEKANJA[j]!=0){
                x=j;
            }
        }
        if(x>0){
            OZNAKA_CEKANJA[x]=0;
            PRIORITET[x]=TEKUCI_PRIORITET;
            TEKUCI_PRIORITET=x;
            dozvoli_prekidanje();
            obrada_signala(x);
            zabrani_prekidanje();
            TEKUCI_PRIORITET=PRIORITET[x];
        }

    } while (x>0);
    dozvoli_prekidanje();

}

int main(){

    sigset(SIGQUIT,prekidna_rutina);
    sigset(SIGALRM,prekidna_rutina);
    sigset(SIGTERM,prekidna_rutina);
    sigset(SIGUSR1,prekidna_rutina);
    sigset(SIGINT,prekidna_rutina);
    sigset(SIGKILL,prekidna_rutina);

    printf("Proces obrade prekida, PID=%ld\n",getpid());

    printf("G 1 2 3 4 5\n");
    printf("-----------\n");

    for (int i = 1; i <=10 ; ++i) {
        printf("%d - - - - -\n",i);
        sleep(1);  // a=sleep(100), while(a=sleep(a)>0));
    }

    printf("Zavrsio osnovni program\n");

    return 0;

}